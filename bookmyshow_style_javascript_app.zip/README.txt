BOOKMYSHOW-STYLE JAVASCRIPT MOVIE BOOKING DEMO

Files:
- index.html
- style.css
- script.js

Features:
1. Movie cards
2. Movie selection
3. Show-time selection
4. Seat selection
5. Already-booked seats
6. Maximum 6 seats per booking
7. Price calculation
8. Customer name validation
9. Phone number validation
10. Booking ID generation
11. Booking-success window
12. Booking window closes automatically after successful booking

How to run:
1. Extract the ZIP.
2. Open index.html in a browser.
3. Select a movie.
4. Select show time and seats.
5. Enter name and 10-digit phone number.
6. Click Confirm Booking.

Important:
This is a front-end educational project. It does not make real bookings, process payments, or store data in a server/database.
