const movies = [
  { id: 1, title: "Adventure World", genre: "Action", price: 180, icon: "🎬" },
  { id: 2, title: "Love Story", genre: "Romance", price: 160, icon: "❤️" },
  { id: 3, title: "Mystery Night", genre: "Thriller", price: 200, icon: "🕵️" },
  { id: 4, title: "Comedy Club", genre: "Comedy", price: 150, icon: "😂" }
];

let selectedMovie = null;
let selectedSeats = [];

const moviesContainer = document.getElementById("movies");
const bookingWindow = document.getElementById("bookingWindow");
const successWindow = document.getElementById("successWindow");

function loadMovies() {
  moviesContainer.innerHTML = movies.map(movie => `
    <div class="movie-card">
      <div class="poster">${movie.icon}</div>
      <h3>${movie.title}</h3>
      <p>${movie.genre} • ₹${movie.price}/seat</p>
      <button class="book" onclick="openBooking(${movie.id})">Book Tickets</button>
    </div>
  `).join("");
}

function openBooking(movieId) {
  selectedMovie = movies.find(movie => movie.id === movieId);
  selectedSeats = [];

  document.getElementById("selectedMovieTitle").textContent =
    selectedMovie.title + " - Booking";

  document.getElementById("customerName").value = "";
  document.getElementById("phone").value = "";

  createSeats();
  updateSummary();

  bookingWindow.classList.remove("hidden");
}

function createSeats() {
  const seatMap = document.getElementById("seatMap");
  seatMap.innerHTML = "";

  const bookedSeats = ["A3", "B5", "C2", "D7", "E4"];

  for (let row = 0; row < 5; row++) {
    const rowLetter = String.fromCharCode(65 + row);

    for (let number = 1; number <= 8; number++) {
      const seatNumber = rowLetter + number;
      const button = document.createElement("button");

      button.textContent = seatNumber;
      button.className = "seat";

      if (bookedSeats.includes(seatNumber)) {
        button.classList.add("booked");
        button.disabled = true;
      } else {
        button.onclick = () => toggleSeat(seatNumber, button);
      }

      seatMap.appendChild(button);
    }
  }
}

function toggleSeat(seatNumber, button) {
  if (selectedSeats.includes(seatNumber)) {
    selectedSeats = selectedSeats.filter(seat => seat !== seatNumber);
    button.classList.remove("selected");
  } else {
    if (selectedSeats.length >= 6) {
      alert("You can select a maximum of 6 seats.");
      return;
    }

    selectedSeats.push(seatNumber);
    button.classList.add("selected");
  }

  updateSummary();
}

function updateSummary() {
  document.getElementById("selectedSeats").textContent =
    selectedSeats.length ? selectedSeats.join(", ") : "None";

  const total = selectedMovie
    ? selectedSeats.length * selectedMovie.price
    : 0;

  document.getElementById("totalPrice").textContent = total;
}

function confirmBooking() {
  const name = document.getElementById("customerName").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const showTime = document.getElementById("showTime").value;

  if (!selectedSeats.length) {
    alert("Please select at least one seat.");
    return;
  }

  if (!name) {
    alert("Please enter your name.");
    return;
  }

  if (!/^\d{10}$/.test(phone)) {
    alert("Please enter a valid 10-digit phone number.");
    return;
  }

  const bookingId = "MB" + Date.now().toString().slice(-8);

  document.getElementById("bookingMessage").textContent =
    `${selectedMovie.title} | ${showTime} | Seats: ${selectedSeats.join(", ")} | Total: ₹${selectedSeats.length * selectedMovie.price}`;

  document.getElementById("bookingId").textContent = bookingId;

  // Close the booking window after successful booking.
  closeBooking();

  // Show success window.
  successWindow.classList.remove("hidden");
}

function closeBooking() {
  bookingWindow.classList.add("hidden");
}

function closeSuccess() {
  successWindow.classList.add("hidden");
}

loadMovies();
